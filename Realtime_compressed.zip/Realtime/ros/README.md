# ROS 1 Noetic Real-time Object Detection

Real-time object detection with depth camera integration for robotics applications using ROS 1 Noetic on Ubuntu 20.04.

## 🎯 Features

- **Real-time object detection** using YOLO v11 with depth information
- **3D position calculation** (x, y, z coordinates in meters)
- **Angle computation** (azimuth and elevation in degrees)
- **Range/distance measurement** from depth camera
- **Multi-object tracking** with unique IDs
- **ROS 1 Noetic integration** for seamless robotics communication
- **Docker support** for Ubuntu 20.04 containers

## 📊 Data Format

Each detected object contains:
- **ID**: Unique tracking identifier
- **Position**: 3D coordinates (x, y, z) in meters
- **Angles**: Azimuth (-180° to +180°) and elevation (-90° to +90°)
- **Range**: Distance from camera in meters
- **Class**: Object class name (person, car, etc.)
- **Confidence**: Detection confidence score
- **Bounding box**: Pixel coordinates in image

## 🚀 Quick Start

### 1. Prerequisites

```bash
# Ubuntu 20.04 with ROS 1 Noetic
sudo apt update
sudo apt install ros-noetic-desktop-full

# Source ROS
echo "source /opt/ros/noetic/setup.bash" >> ~/.bashrc
source ~/.bashrc

# Create catkin workspace
mkdir -p ~/catkin_ws/src
cd ~/catkin_ws
catkin_make
echo "source ~/catkin_ws/devel/setup.bash" >> ~/.bashrc
source ~/.bashrc
```

### 2. Installation

```bash
# Clone/copy the ros folder to your catkin workspace
cd ~/catkin_ws/src
# Copy the entire 'ros' folder here and rename to 'realtime_object_detection'
cp -r /path/to/your/ros realtime_object_detection

# Run setup script
cd realtime_object_detection
chmod +x setup_ros.sh
./setup_ros.sh
```

### 3. Usage

#### Camera Machine (Publisher)
```bash
# Start ROS core (if not already running)
roscore

# In another terminal - start object detection publisher
roslaunch realtime_object_detection publisher_only.launch
```

#### Master Machine (Subscriber)
```bash
# Make sure ROS_MASTER_URI points to the camera machine
export ROS_MASTER_URI=http://CAMERA_MACHINE_IP:11311

# Start subscriber
roslaunch realtime_object_detection subscriber_only.launch
```

## 🔧 Configuration

### Camera Parameters

Update camera intrinsics in `scripts/realtime_detector_node.py`:

```python
self.camera_intrinsics = {
    'fx': 616.4,  # Focal length X
    'fy': 616.8,  # Focal length Y  
    'cx': 320.0,  # Principal point X
    'cy': 240.0   # Principal point Y
}
```

### Model Path

Update YOLO model path in launch files:

```xml
<arg name="model_path" default="/path/to/your/best.pt" />
```

### Topics

Default topics:
- `/detected_objects` - Main detection data
- `/camera/annotated_image` - Visualized image with detections

## 📡 ROS Topics

### Published Topics

#### `/detected_objects` (realtime_object_detection/DetectedObjects)
Main topic containing all detection data:

```
Header header
uint32 frame_id
uint32 detection_count
float32 processing_time
string camera_frame
geometry_msgs/Point camera_position
DetectedObject[] objects
float32 fps
bool gpu_available
```

#### `/camera/annotated_image` (sensor_msgs/Image)
Visualized image with bounding boxes and labels.

### Message Types

#### DetectedObject
```
Header header
int32 id                    # Tracking ID
string class_name           # Object class
float32 confidence          # Detection confidence
geometry_msgs/Point position  # 3D position (x,y,z)
float32 azimuth            # Horizontal angle (degrees)
float32 elevation          # Vertical angle (degrees)  
float32 range              # Distance (meters)
float32 depth_mm           # Raw depth (millimeters)
float32[] bbox             # Bounding box [x1,y1,x2,y2]
bool valid_depth           # Depth reliability flag
uint32 frame_id            # Frame number
```

## 🐳 Docker Usage

If running in Docker containers:

```bash
# In your Docker container
# Make sure to expose ROS ports and set ROS_MASTER_URI correctly

# Camera container
docker run -it --network host --device /dev/video0 your_image
export ROS_MASTER_URI=http://localhost:11311
roslaunch realtime_object_detection publisher_only.launch

# Master container  
docker run -it --network host your_image
export ROS_MASTER_URI=http://CAMERA_CONTAINER_IP:11311
roslaunch realtime_object_detection subscriber_only.launch
```

## 📋 Example Usage in Your Code

### Subscriber Example

```python
#!/usr/bin/env python3
import rospy
from realtime_object_detection.msg import DetectedObjects

class NavigationSystem:
    def __init__(self):
        rospy.init_node('navigation_system')
        self.sub = rospy.Subscriber('/detected_objects', DetectedObjects, self.detection_callback)
    
    def detection_callback(self, msg):
        print(f"Received {msg.detection_count} objects in frame {msg.frame_id}")
        
        for obj in msg.objects:
            print(f"Object {obj.id} ({obj.class_name}):")
            print(f"  Position: x={obj.position.x:.2f}m, y={obj.position.y:.2f}m, z={obj.position.z:.2f}m")
            print(f"  Angles: azimuth={obj.azimuth:.1f}°, elevation={obj.elevation:.1f}°")
            print(f"  Range: {obj.range:.2f}m")
            print(f"  Confidence: {obj.confidence:.2f}")
            
            # Use this data for navigation/SLAM
            self.process_for_navigation(obj)
    
    def process_for_navigation(self, detected_object):
        # Your navigation logic here
        if detected_object.class_name == 'person' and detected_object.range < 2.0:
            print("⚠️  Person detected nearby - consider stopping/slowing")
        elif detected_object.class_name == 'car':
            print("🚗 Vehicle detected - update obstacle map")

if __name__ == '__main__':
    nav = NavigationSystem()
    rospy.spin()
```

## 🔍 Debugging

### Check ROS Topics
```bash
# List all topics
rostopic list

# Monitor detection topic
rostopic echo /detected_objects

# Check message rate
rostopic hz /detected_objects
```

### Check Node Status
```bash
# List running nodes
rosnode list

# Get node info
rosnode info /realtime_detector
```

### Visualize Data
```bash
# View annotated images
rosrun image_view image_view image:=/camera/annotated_image
```

## 🛠️ Troubleshooting

### Common Issues

1. **"Custom messages not found"**
   ```bash
   cd ~/catkin_ws
   catkin_make
   source devel/setup.bash
   ```

2. **Camera not detected**
   - Check camera connection
   - Verify permissions: `sudo chmod 666 /dev/video*`
   - Test with: `ls /dev/video*`

3. **Model not found**
   - Update model path in launch file
   - Ensure model file exists and is readable

4. **ROS connection issues**
   - Check `ROS_MASTER_URI`
   - Ensure network connectivity between machines
   - Verify firewall settings (port 11311)

### Performance Optimization

```xml
<!-- In launch file -->
<param name="publish_rate" value="15.0" />  <!-- Reduce for better performance -->
<param name="use_realsense" value="true" />  <!-- Hardware acceleration -->
```

## 🤝 Integration with SLAM/Navigation

The detection data is designed for easy integration with:
- **ROS Navigation Stack**
- **SLAM algorithms** (gmapping, hector_slam, etc.)
- **Move Base** for path planning
- **Custom navigation systems**

Example integration points:
- Use detected objects as **dynamic obstacles**
- Convert positions to **occupancy grid updates**
- Create **semantic landmarks** for SLAM
- Implement **person-following** behaviors

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Verify ROS installation and sourcing
3. Test with minimal launch files
4. Check ROS logs: `roscd log`

---

**Good luck with your robotics project! 🤖🚀**
