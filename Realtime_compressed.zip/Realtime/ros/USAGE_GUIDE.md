# 🚀 Complete Setup and Usage Guide
## ROS 1 Noetic Real-time Object Detection

This guide will help you set up and use the real-time object detection system with ROS 1 Noetic for sending object data (ID, position x/y/z, angles, range) to your master machine.

## 📋 Quick Setup Checklist

### ✅ Prerequisites
- [ ] Ubuntu 20.04 LTS (or Docker container)
- [ ] ROS 1 Noetic installed
- [ ] Python 3.8+
- [ ] Intel RealSense camera (or compatible depth camera)
- [ ] YOLO model file (`best PT 3500.pt`)

### ✅ Installation Steps

1. **Install ROS 1 Noetic** (if not already installed):
```bash
# Add ROS repository
sudo sh -c 'echo "deb http://packages.ros.org/ros/ubuntu $(lsb_release -sc) main" > /etc/apt/sources.list.d/ros-latest.list'
sudo apt-key adv --keyserver 'hkp://keyserver.ubuntu.com:80' --recv-key C1CF6E31E6BADE8868B172B4F42ED6FBAB17C654

# Install ROS
sudo apt update
sudo apt install ros-noetic-desktop-full

# Setup environment
echo "source /opt/ros/noetic/setup.bash" >> ~/.bashrc
source ~/.bashrc
```

2. **Create Catkin Workspace**:
```bash
mkdir -p ~/catkin_ws/src
cd ~/catkin_ws
catkin_make
echo "source ~/catkin_ws/devel/setup.bash" >> ~/.bashrc
source ~/.bashrc
```

3. **Install Dependencies**:
```bash
# ROS dependencies
sudo apt install ros-noetic-cv-bridge ros-noetic-vision-opencv python3-catkin-tools

# Python dependencies
pip3 install opencv-python ultralytics supervision pyrealsense2 numpy torch
```

4. **Setup the Package**:
```bash
cd ~/catkin_ws/src
# Copy the 'ros' folder from your project and rename it
cp -r /path/to/your/ros realtime_object_detection

# Build the package
cd ~/catkin_ws
catkin_make
source devel/setup.bash
```

## 🎯 Usage Scenarios

### Scenario 1: Camera Machine + Master Machine (Recommended)

**On Camera Machine (with depth camera):**
```bash
# Terminal 1: Start ROS master
roscore

# Terminal 2: Start object detection publisher
cd ~/catkin_ws
source devel/setup.bash
roslaunch realtime_object_detection publisher_only.launch
```

**On Master Machine:**
```bash
# Set ROS master to camera machine
export ROS_MASTER_URI=http://CAMERA_MACHINE_IP:11311

# Start subscriber
cd ~/catkin_ws
source devel/setup.bash
roslaunch realtime_object_detection subscriber_only.launch
```

### Scenario 2: Single Machine Testing
```bash
# Terminal 1: Start everything
roslaunch realtime_object_detection realtime_detection.launch

# Terminal 2: Monitor data
rostopic echo /detected_objects
```

### Scenario 3: Docker Setup

**Camera Container:**
```bash
docker run -it --network host --device /dev/video0 --device /dev/bus/usb \
  -v /path/to/your/model:/models your_ros_image

# Inside container
export ROS_MASTER_URI=http://localhost:11311
roslaunch realtime_object_detection publisher_only.launch
```

**Master Container:**
```bash
docker run -it --network host your_ros_image

# Inside container  
export ROS_MASTER_URI=http://CAMERA_CONTAINER_IP:11311
roslaunch realtime_object_detection subscriber_only.launch
```

## 📊 Data Format Received

When you subscribe to `/detected_objects`, you'll receive:

```python
# Example callback function
def detection_callback(self, msg):
    print(f"Frame {msg.frame_id}: {msg.detection_count} objects detected")
    
    for obj in msg.objects:
        print(f"Object ID: {obj.id}")
        print(f"Class: {obj.class_name}")
        print(f"Position: x={obj.position.x:.2f}m, y={obj.position.y:.2f}m, z={obj.position.z:.2f}m")
        print(f"Azimuth: {obj.azimuth:.1f}° (horizontal angle)")
        print(f"Elevation: {obj.elevation:.1f}° (vertical angle)")
        print(f"Range: {obj.range:.2f}m (distance from camera)")
        print(f"Confidence: {obj.confidence:.2f}")
        print("---")
```

## 🔧 Configuration

### Camera Parameters
Edit `scripts/realtime_detector_node.py`:
```python
self.camera_intrinsics = {
    'fx': 616.4,  # Your camera's focal length X
    'fy': 616.8,  # Your camera's focal length Y
    'cx': 320.0,  # Principal point X (usually image_width/2)
    'cy': 240.0   # Principal point Y (usually image_height/2)
}
```

### Model Path
Update in launch files or set as parameter:
```xml
<param name="model_path" value="/path/to/your/best PT 3500.pt" />
```

### Performance Tuning
```xml
<param name="publish_rate" value="30.0" />  <!-- Publishing frequency -->
<param name="use_realsense" value="true" /> <!-- Hardware acceleration -->
```

## 🧪 Testing

### Test 1: Check ROS Installation
```bash
# Check ROS
roscore &
rostopic list
rosnode list

# Should see ROS topics and core nodes
```

### Test 2: Test Detection System
```bash
cd ~/catkin_ws/src/realtime_object_detection
python3 scripts/test_detection_system.py &
python3 scripts/test_detection_system.py subscriber
```

### Test 3: Monitor Real Data
```bash
# Terminal 1: Start publisher
roslaunch realtime_object_detection publisher_only.launch

# Terminal 2: Monitor data
rostopic echo /detected_objects
rostopic hz /detected_objects  # Check publishing frequency
```

## 🔍 Troubleshooting

### Issue: "Custom messages not found"
**Solution:**
```bash
cd ~/catkin_ws
catkin_make
source devel/setup.bash
```

### Issue: "Camera not detected"
**Solution:**
```bash
# Check camera connection
ls /dev/video*

# Check permissions
sudo chmod 666 /dev/video*

# For RealSense
sudo apt install librealsense2-utils
realsense-viewer  # Test camera
```

### Issue: "Model not found"
**Solution:**
```bash
# Check model path
ls -la /path/to/your/best.pt

# Update path in launch file
<param name="model_path" value="/correct/path/to/best.pt" />
```

### Issue: "ROS connection problems"
**Solution:**
```bash
# Check ROS master URI
echo $ROS_MASTER_URI

# Test connection
rosnode ping /rosout

# Check network (for multi-machine setup)
ping CAMERA_MACHINE_IP
telnet CAMERA_MACHINE_IP 11311
```

### Issue: Performance problems
**Solution:**
```bash
# Reduce publishing rate
<param name="publish_rate" value="15.0" />

# Check system resources
htop
nvidia-smi  # If using GPU
```

## 💡 Integration Examples

### Example 1: Basic Subscriber
```python
#!/usr/bin/env python3
import rospy
from realtime_object_detection.msg import DetectedObjects

def callback(msg):
    for obj in msg.objects:
        if obj.class_name == 'person' and obj.range < 2.0:
            print(f"⚠️  Person {obj.id} at {obj.range:.2f}m")
            # Add your navigation logic here

rospy.init_node('navigation_node')
rospy.Subscriber('/detected_objects', DetectedObjects, callback)
rospy.spin()
```

### Example 2: Obstacle Avoidance
```python
def process_for_navigation(self, msg):
    obstacles = []
    for obj in msg.objects:
        if obj.range < 3.0:  # Objects within 3 meters
            obstacles.append({
                'id': obj.id,
                'position': [obj.position.x, obj.position.y, obj.position.z],
                'type': obj.class_name,
                'distance': obj.range,
                'angle': obj.azimuth  # Use for steering decisions
            })
    
    return obstacles
```

## 📞 Support & Next Steps

### Verification Commands
```bash
# Check if everything is working
rosnode list | grep realtime_detector
rostopic list | grep detected
rostopic hz /detected_objects
rosrun rqt_graph rqt_graph  # Visualize ROS graph
```

### Performance Monitoring  
```bash
# Monitor system performance
rosrun rqt_plot rqt_plot /detected_objects/fps
rosrun rqt_console rqt_console  # View logs
```

### Next Integration Steps
1. **Create your navigation subscriber** using the examples above
2. **Convert object positions** to your robot's coordinate frame
3. **Integrate with your SLAM system** for obstacle mapping
4. **Add robot control logic** based on detected objects
5. **Implement safety protocols** for critical detections

---

## 🎉 You're Ready!

Your ROS 1 Noetic real-time object detection system is now set up to send:
- **Object ID**: Unique tracking identifier
- **Position**: 3D coordinates (x, y, z) in meters
- **Angles**: Azimuth and elevation in degrees  
- **Range**: Distance from camera in meters
- **Multiple objects**: All detections in each frame

The data is transmitted in real-time via ROS topics, ready for your navigation and SLAM systems! 🤖🚀
