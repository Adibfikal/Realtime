#!/bin/bash
# Setup script for ROS 1 Noetic Real-time Object Detection
# Run this script to set up the ROS package

echo "🚀 Setting up ROS 1 Noetic Real-time Object Detection"

# Check if ROS is installed
if ! command -v roscore &> /dev/null; then
    echo "❌ ROS is not installed or not sourced"
    echo "Please install ROS 1 Noetic and source setup.bash"
    echo "Source: http://wiki.ros.org/noetic/Installation/Ubuntu"
    exit 1
fi

echo "✅ ROS found: $(rosversion -d)"

# Check for catkin workspace
if [ -z "$ROS_PACKAGE_PATH" ]; then
    echo "❌ No catkin workspace found"
    echo "Please create and source a catkin workspace first:"
    echo "  mkdir -p ~/catkin_ws/src"
    echo "  cd ~/catkin_ws && catkin_make"
    echo "  source devel/setup.bash"
    exit 1
fi

echo "✅ Catkin workspace found"

# Get the directory of this script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
PACKAGE_DIR="$SCRIPT_DIR"

# Find catkin workspace src directory
CATKIN_WS=$(echo $ROS_PACKAGE_PATH | cut -d: -f1)
SRC_DIR="$CATKIN_WS/../src"

echo "📁 Package directory: $PACKAGE_DIR"
echo "📁 Catkin src directory: $SRC_DIR"

# Create symbolic link to the package
LINK_PATH="$SRC_DIR/realtime_object_detection"

if [ -L "$LINK_PATH" ]; then
    echo "🔗 Package link already exists, removing old link"
    rm "$LINK_PATH"
fi

echo "🔗 Creating symbolic link to package"
ln -s "$PACKAGE_DIR" "$LINK_PATH"

# Install Python dependencies
echo "📦 Installing Python dependencies"
pip3 install --user opencv-python pyrealsense2 ultralytics supervision

# Install ROS Python dependencies
echo "📦 Installing ROS Python dependencies"
sudo apt-get update
sudo apt-get install -y ros-noetic-cv-bridge ros-noetic-vision-opencv python3-catkin-tools

# Build the package
echo "🔨 Building ROS package"
cd "$CATKIN_WS/.."
catkin_make

if [ $? -eq 0 ]; then
    echo "✅ Package built successfully"
    
    # Source the workspace
    source devel/setup.bash
    
    echo "🎉 Setup completed successfully!"
    echo ""
    echo "📋 Next steps:"
    echo "1. Make sure your camera is connected"
    echo "2. Update model path in launch files if needed"
    echo "3. Run: roslaunch realtime_object_detection publisher_only.launch"
    echo ""
    echo "💡 Usage examples:"
    echo "Publisher (camera machine): roslaunch realtime_object_detection publisher_only.launch"
    echo "Subscriber (master machine): roslaunch realtime_object_detection subscriber_only.launch"
    echo "Both: roslaunch realtime_object_detection realtime_detection.launch"
    
else
    echo "❌ Package build failed"
    echo "Please check the error messages above"
    exit 1
fi
