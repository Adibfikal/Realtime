#!/bin/bash
# Quick start script for ROS 1 Noetic Real-time Object Detection
# This script helps you get the system running quickly

echo "🚀 ROS 1 Noetic Real-time Object Detection Quick Start"
echo "=================================================="

# Check if we're in the right directory
if [ ! -f "scripts/realtime_detector_node.py" ]; then
    echo "❌ Please run this script from the ros package directory"
    echo "Expected structure: ros/scripts/realtime_detector_node.py"
    exit 1
fi

# Function to check if ROS is running
check_ros() {
    if ! pgrep roscore > /dev/null; then
        echo "⚠️  ROS master not running. Starting roscore..."
        roscore &
        sleep 3
        echo "✅ ROS master started"
    else
        echo "✅ ROS master already running"
    fi
}

# Function to check dependencies
check_dependencies() {
    echo "🔍 Checking dependencies..."
    
    # Check if package is built
    if [ ! -f "../../devel/lib/realtime_object_detection/realtime_detector_node.py" ]; then
        echo "📦 Building ROS package..."
        cd ../../
        catkin_make
        if [ $? -eq 0 ]; then
            echo "✅ Package built successfully"
        else
            echo "❌ Package build failed"
            exit 1
        fi
        cd src/realtime_object_detection
    fi
    
    # Check Python dependencies
    python3 -c "import cv2, numpy, ultralytics, supervision" 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "✅ Python dependencies OK"
    else
        echo "⚠️  Installing Python dependencies..."
        pip3 install opencv-python ultralytics supervision numpy
    fi
    
    # Check ROS dependencies
    python3 -c "import rospy, cv_bridge" 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "✅ ROS Python dependencies OK"
    else
        echo "❌ ROS Python dependencies missing"
        echo "Install with: sudo apt install ros-noetic-cv-bridge ros-noetic-vision-opencv"
        exit 1
    fi
}

# Function to show usage options
show_usage() {
    echo ""
    echo "📋 Usage Options:"
    echo "1. ./quick_start.sh publisher    - Start camera publisher (camera machine)"
    echo "2. ./quick_start.sh subscriber   - Start data subscriber (master machine)"
    echo "3. ./quick_start.sh test         - Run test with simulated data"
    echo "4. ./quick_start.sh full         - Start both publisher and subscriber"
    echo ""
}

# Source ROS environment
source_ros() {
    if [ -f "/opt/ros/noetic/setup.bash" ]; then
        source /opt/ros/noetic/setup.bash
        echo "✅ ROS environment sourced"
    else
        echo "❌ ROS not found. Please install ROS 1 Noetic"
        exit 1
    fi
    
    # Source workspace if available
    if [ -f "../../devel/setup.bash" ]; then
        source ../../devel/setup.bash
        echo "✅ Workspace sourced"
    fi
}

# Main execution
case "$1" in
    "publisher")
        echo "🎥 Starting Object Detection Publisher (Camera Machine)"
        check_dependencies
        source_ros
        check_ros
        
        echo "🔄 Launching publisher node..."
        roslaunch realtime_object_detection publisher_only.launch
        ;;
        
    "subscriber")
        echo "📡 Starting Object Detection Subscriber (Master Machine)"
        check_dependencies
        source_ros
        
        # Check for ROS master
        echo "🔍 Checking for ROS master..."
        if [ -z "$ROS_MASTER_URI" ]; then
            echo "⚠️  ROS_MASTER_URI not set. Using localhost"
            export ROS_MASTER_URI=http://localhost:11311
        fi
        echo "📍 ROS Master: $ROS_MASTER_URI"
        
        echo "🔄 Launching subscriber node..."
        roslaunch realtime_object_detection subscriber_only.launch
        ;;
        
    "test")
        echo "🧪 Starting Test Mode"
        check_dependencies
        source_ros
        check_ros
        
        echo "🔄 Running detection system test..."
        python3 scripts/test_detection_system.py &
        TEST_PID=$!
        
        sleep 2 
        echo "🎧 Starting test subscriber..."
        python3 scripts/test_detection_system.py subscriber &
        SUBSCRIBER_PID=$!
        
        echo "⏰ Test running for 30 seconds. Press Ctrl+C to stop early."
        trap "kill $TEST_PID $SUBSCRIBER_PID 2>/dev/null; exit" INT
        wait $TEST_PID
        kill $SUBSCRIBER_PID 2>/dev/null
        echo "✅ Test completed"
        ;;
        
    "full")
        echo "🎯 Starting Full System (Publisher + Subscriber)"
        check_dependencies
        source_ros
        check_ros
        
        echo "🔄 Launching full system..."
        roslaunch realtime_object_detection realtime_detection.launch
        ;;
        
    "setup")
        echo "⚙️  Running Setup..."
        chmod +x setup_ros.sh
        ./setup_ros.sh
        ;;
        
    *)
        echo "❓ Unknown option: $1"
        show_usage
        echo "Examples:"
        echo "  # On camera machine:"
        echo "  ./quick_start.sh publisher"
        echo ""
        echo "  # On master machine (set ROS_MASTER_URI first):"
        echo "  export ROS_MASTER_URI=http://CAMERA_MACHINE_IP:11311"
        echo "  ./quick_start.sh subscriber"
        echo ""
        echo "  # Test locally:"
        echo "  ./quick_start.sh test"
        exit 1
        ;;
esac
