#!/usr/bin/env python3
"""
Real-time Object Detection ROS Publisher
Publishes detected objects with 3D position, angles, and range data to ROS topics
Compatible with ROS 1 Noetic on Ubuntu 20.04
"""

import rospy
import cv2
import numpy as np
import time
import threading
from std_msgs.msg import Header
from geometry_msgs.msg import Point
from sensor_msgs.msg import Image, CameraInfo
from cv_bridge import CvBridge
import pyrealsense2 as rs

# Import custom messages (make sure your package is built first)
try:
    from realtime_object_detection.msg import DetectedObject, DetectedObjects
except ImportError:
    rospy.logwarn("Custom messages not found. Make sure to build the ROS package first:")
    rospy.logwarn("cd /path/to/catkin_ws && catkin_make")
    rospy.logwarn("source devel/setup.bash")
    exit(1)

# Import your object detection processor
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from object_detection_processor import ObjectDetectionProcessor


class RealTimeObjectDetectionNode:
    """
    ROS Node for real-time object detection with depth information
    Publishes detection data that includes ID, position (x,y,z), angles, and range
    """
    
    def __init__(self):
        # Initialize ROS node
        rospy.init_node('realtime_object_detection', anonymous=True)
        
        # ROS Parameters
        self.camera_frame = rospy.get_param('~camera_frame', 'camera_link')
        self.publish_rate = rospy.get_param('~publish_rate', 30.0)  # Hz
        self.model_path = rospy.get_param('~model_path', '../PredictModel/best PT 3500.pt')
        self.detection_topic = rospy.get_param('~detection_topic', '/detected_objects')
        self.image_topic = rospy.get_param('~image_topic', '/camera/color/image_raw')
        self.use_realsense = rospy.get_param('~use_realsense', True)
        
        rospy.loginfo(f"Starting Real-time Object Detection Node")
        rospy.loginfo(f"Publishing to topic: {self.detection_topic}")
        rospy.loginfo(f"Camera frame: {self.camera_frame}")
        rospy.loginfo(f"Publish rate: {self.publish_rate} Hz")
        
        # Initialize object detection processor
        self.detector = ObjectDetectionProcessor(model_path=self.model_path)
        success, message = self.detector.load_model()
        if not success:
            rospy.logerr(f"Failed to load detection model: {message}")
            return
        rospy.loginfo(f"Detection model loaded: {message}")
        
        # ROS Publishers
        self.objects_pub = rospy.Publisher(
            self.detection_topic, 
            DetectedObjects, 
            queue_size=10
        )
        self.image_pub = rospy.Publisher(
            '/camera/annotated_image', 
            Image, 
            queue_size=5
        )
        
        # Initialize camera
        self.bridge = CvBridge()
        self.camera_intrinsics = {
            'fx': 616.4, 'fy': 616.8,
            'cx': 320.0, 'cy': 240.0
        }
        
        # Performance tracking
        self.frame_count = 0
        self.last_fps_time = time.time()
        self.fps = 0.0
        
        # Initialize camera system
        if self.use_realsense:
            self.init_realsense_camera()
        else:
            rospy.loginfo("Using ROS image topics for camera input")
            self.image_sub = rospy.Subscriber(
                self.image_topic, Image, self.image_callback
            )
        
        # Start main processing loop
        self.processing_thread = threading.Thread(target=self.processing_loop)
        self.processing_thread.daemon = True
        self.processing_thread.start()
        
        rospy.loginfo("Real-time Object Detection Node started successfully!")
    
    def init_realsense_camera(self):
        """Initialize Intel RealSense camera"""
        try:
            self.pipeline = rs.pipeline()
            config = rs.config()
            
            # Configure streams
            config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
            config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
            
            # Start streaming
            profile = self.pipeline.start(config)
            
            # Get camera intrinsics
            color_stream = profile.get_stream(rs.stream.color)
            intrinsics = color_stream.as_video_stream_profile().get_intrinsics()
            
            self.camera_intrinsics = {
                'fx': intrinsics.fx,
                'fy': intrinsics.fy, 
                'cx': intrinsics.ppx,
                'cy': intrinsics.ppy
            }
            
            rospy.loginfo(f"RealSense camera initialized")
            rospy.loginfo(f"Camera intrinsics: {self.camera_intrinsics}")
            
        except Exception as e:
            rospy.logerr(f"Failed to initialize RealSense camera: {e}")
            rospy.loginfo("Falling back to ROS image topics")
            self.use_realsense = False
    
    def image_callback(self, msg):
        """Callback for ROS image messages (fallback mode)"""
        try:
            # Convert ROS image to OpenCV format
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            
            # For this callback mode, we'll need depth from another topic
            # This is simplified - you should subscribe to depth topic too
            rospy.logwarn_once("Image callback mode - depth data not available")
            
        except Exception as e:
            rospy.logerr(f"Error in image callback: {e}")
    
    def get_camera_frames(self):
        """Get RGB and depth frames from camera"""
        if self.use_realsense:
            try:
                # Wait for frames
                frames = self.pipeline.wait_for_frames(timeout_ms=1000)
                color_frame = frames.get_color_frame()
                depth_frame = frames.get_depth_frame()
                
                if not color_frame or not depth_frame:
                    return None, None
                
                # Convert to numpy arrays
                color_image = np.asanyarray(color_frame.get_data())
                depth_image = np.asanyarray(depth_frame.get_data())
                
                return color_image, depth_image
                
            except Exception as e:
                rospy.logerr_throttle(5.0, f"Error getting RealSense frames: {e}")
                return None, None
        else:
            # Fallback mode - would need to implement ROS topic subscription
            rospy.logwarn_once("ROS topic mode not fully implemented in this example")
            return None, None
    
    def create_detected_object_msg(self, detection_info, frame_id):
        """Create DetectedObject message from detection data"""
        obj_msg = DetectedObject()
        
        # Header
        obj_msg.header = Header()
        obj_msg.header.stamp = rospy.Time.now()
        obj_msg.header.frame_id = self.camera_frame
        
        # Object identification
        obj_msg.id = detection_info.get('tracker_id', -1)
        obj_msg.class_name = detection_info.get('class_name', 'unknown')
        obj_msg.confidence = detection_info.get('confidence', 0.0)
        
        # 3D Position
        position_3d = detection_info.get('position_3d', {})
        obj_msg.position = Point()
        obj_msg.position.x = position_3d.get('x', 0.0)
        obj_msg.position.y = position_3d.get('y', 0.0) 
        obj_msg.position.z = position_3d.get('z', 0.0)
        
        # Angles
        obj_msg.azimuth = position_3d.get('azimuth', 0.0)
        obj_msg.elevation = position_3d.get('elevation', 0.0)
        
        # Range/Distance
        obj_msg.range = position_3d.get('z', 0.0)  # Same as z coordinate
        obj_msg.depth_mm = detection_info.get('depth_mm', 0.0)
        
        # Bounding box
        bbox = detection_info.get('bbox', [0, 0, 0, 0])
        obj_msg.bbox = [float(x) for x in bbox]
        
        # Metadata
        obj_msg.valid_depth = position_3d.get('valid', False)
        obj_msg.frame_id = frame_id
        
        return obj_msg
    
    def processing_loop(self):
        """Main processing loop for object detection"""
        rate = rospy.Rate(self.publish_rate)
        
        while not rospy.is_shutdown():
            start_time = time.time()
            
            # Get camera frames
            rgb_frame, depth_frame = self.get_camera_frames()
            
            if rgb_frame is None or depth_frame is None:
                rate.sleep()
                continue
            
            try:
                # Process frame with object detection
                annotated_frame, detection_data = self.detector.process_frame(
                    rgb_frame, depth_frame, self.camera_intrinsics
                )
                
                # Create and publish DetectedObjects message
                if 'detections' in detection_data:
                    objects_msg = DetectedObjects()
                    
                    # Header
                    objects_msg.header = Header()
                    objects_msg.header.stamp = rospy.Time.now()
                    objects_msg.header.frame_id = self.camera_frame
                    
                    # Metadata
                    objects_msg.frame_id = self.frame_count
                    objects_msg.detection_count = len(detection_data['detections'])
                    objects_msg.processing_time = time.time() - start_time
                    objects_msg.camera_frame = self.camera_frame
                    objects_msg.camera_position = Point(0, 0, 0)  # Set if known
                    objects_msg.fps = self.fps
                    objects_msg.gpu_available = detection_data.get('gpu_available', False)
                    
                    # Add detected objects
                    objects_msg.objects = []
                    for detection in detection_data['detections']:
                        obj_msg = self.create_detected_object_msg(detection, self.frame_count)
                        objects_msg.objects.append(obj_msg)
                    
                    # Publish detection data
                    self.objects_pub.publish(objects_msg)
                    
                    # Log detection info
                    if objects_msg.detection_count > 0:
                        rospy.loginfo_throttle(1.0, 
                            f"Published {objects_msg.detection_count} detections "
                            f"(Frame: {self.frame_count}, FPS: {self.fps:.1f})"
                        )
                
                # Publish annotated image
                if annotated_frame is not None:
                    try:
                        # Convert BGR to RGB for ROS
                        annotated_rgb = cv2.cvtColor(annotated_frame, cv2.COLOR_BGR2RGB)
                        img_msg = self.bridge.cv2_to_imgmsg(annotated_rgb, "rgb8")
                        img_msg.header.stamp = rospy.Time.now()
                        img_msg.header.frame_id = self.camera_frame
                        self.image_pub.publish(img_msg)
                    except Exception as e:
                        rospy.logerr_throttle(5.0, f"Error publishing image: {e}")
                
                # Update performance metrics
                self.frame_count += 1
                current_time = time.time()
                if current_time - self.last_fps_time >= 1.0:
                    self.fps = 1.0 / (current_time - self.last_fps_time) if self.last_fps_time > 0 else 0
                    self.last_fps_time = current_time
                
            except Exception as e:
                rospy.logerr(f"Error in processing loop: {e}")
            
            rate.sleep()
    
    def shutdown(self):
        """Clean shutdown"""
        rospy.loginfo("Shutting down Real-time Object Detection Node...")
        if hasattr(self, 'pipeline') and self.use_realsense:
            try:
                self.pipeline.stop()
            except:
                pass


def main():
    try:
        # Create and run the node
        node = RealTimeObjectDetectionNode()
        
        # Keep node running
        rospy.spin()
        
    except rospy.ROSInterruptException:
        rospy.loginfo("Node interrupted")
    except Exception as e:
        rospy.logerr(f"Node failed: {e}")
    finally:
        if 'node' in locals():
            node.shutdown()


if __name__ == '__main__':
    main()
