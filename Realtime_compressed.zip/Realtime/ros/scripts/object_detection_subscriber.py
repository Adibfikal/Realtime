#!/usr/bin/env python3
"""
Object Detection Subscriber for Master Machine
Subscribes to real-time object detection data and processes it for navigation/SLAM
Compatible with ROS 1 Noetic on Ubuntu 20.04
"""

import rospy
import json
import time
from collections import defaultdict

# Import custom messages
try:
    from realtime_object_detection.msg import DetectedObject, DetectedObjects
except ImportError:
    rospy.logwarn("Custom messages not found. Make sure to build the ROS package first.")
    exit(1)


class ObjectDetectionSubscriber:
    """
    ROS Subscriber for receiving real-time object detection data
    Processes detection data for navigation and SLAM systems
    """
    
    def __init__(self):
        # Initialize ROS node
        rospy.init_node('object_detection_subscriber', anonymous=True)
        
        # ROS Parameters
        self.detection_topic = rospy.get_param('~detection_topic', '/detected_objects')
        self.log_detections = rospy.get_param('~log_detections', True)
        self.save_to_file = rospy.get_param('~save_to_file', False)
        self.output_file = rospy.get_param('~output_file', 'detection_log.json')
        
        rospy.loginfo(f"Starting Object Detection Subscriber")
        rospy.loginfo(f"Subscribing to topic: {self.detection_topic}")
        
        # Data storage
        self.detection_history = []
        self.object_tracks = defaultdict(list)  # Track objects by ID over time
        self.latest_detections = None
        
        # Statistics
        self.total_frames = 0
        self.total_objects = 0
        self.start_time = time.time()
        
        # ROS Subscriber
        self.objects_sub = rospy.Subscriber(
            self.detection_topic,
            DetectedObjects,
            self.detection_callback,
            queue_size=10
        )
        
        rospy.loginfo("Object Detection Subscriber started successfully!")
        
        # Timer for periodic logging
        if self.log_detections:
            self.log_timer = rospy.Timer(rospy.Duration(5.0), self.log_statistics)
    
    def detection_callback(self, msg):
        """Callback function for receiving detection data"""
        try:
            # Update statistics
            self.total_frames += 1
            self.total_objects += msg.detection_count
            self.latest_detections = msg
            
            # Process each detected object
            frame_data = {
                'timestamp': msg.header.stamp.to_sec(),
                'frame_id': msg.frame_id,
                'detection_count': msg.detection_count,
                'processing_time': msg.processing_time,
                'fps': msg.fps,
                'objects': []
            }
            
            rospy.loginfo(f"Received frame {msg.frame_id} with {msg.detection_count} detections")
            
            for i, obj in enumerate(msg.objects):
                # Extract object data
                obj_data = {
                    'id': obj.id,
                    'class_name': obj.class_name,
                    'confidence': obj.confidence,
                    'position': {
                        'x': obj.position.x,
                        'y': obj.position.y,
                        'z': obj.position.z
                    },
                    'angles': {
                        'azimuth': obj.azimuth,
                        'elevation': obj.elevation
                    },
                    'range': obj.range,
                    'depth_mm': obj.depth_mm,
                    'bbox': obj.bbox,
                    'valid_depth': obj.valid_depth
                }
                
                frame_data['objects'].append(obj_data)
                
                # Update object tracking
                self.object_tracks[obj.id].append({
                    'timestamp': msg.header.stamp.to_sec(),
                    'position': obj_data['position'],
                    'angles': obj_data['angles'],
                    'range': obj.range
                })
                
                # Log individual object (for debugging)
                rospy.loginfo(
                    f"  Object {obj.id} ({obj.class_name}): "
                    f"pos=({obj.position.x:.2f}, {obj.position.y:.2f}, {obj.position.z:.2f}m), "
                    f"angles=({obj.azimuth:.1f}°, {obj.elevation:.1f}°), "
                    f"range={obj.range:.2f}m, conf={obj.confidence:.2f}"
                )
            
            # Store frame data
            self.detection_history.append(frame_data)
            
            # Save to file if requested
            if self.save_to_file:
                self.save_detection_data(frame_data)
            
            # Call your custom processing function
            self.process_for_navigation(frame_data)
            
        except Exception as e:
            rospy.logerr(f"Error in detection callback: {e}")
    
    def process_for_navigation(self, frame_data):
        """
        Process detection data for navigation/SLAM system
        Implement your specific navigation logic here
        """
        # Example processing for navigation system
        obstacles = []
        landmarks = []
        
        for obj in frame_data['objects']:
            if obj['valid_depth'] and obj['range'] > 0:
                # Classify objects for navigation
                if obj['class_name'] in ['person', 'car', 'bicycle', 'motorcycle']:
                    # Dynamic obstacles
                    obstacles.append({
                        'id': obj['id'],
                        'type': 'dynamic',
                        'class': obj['class_name'],
                        'position': obj['position'],
                        'range': obj['range'],
                        'azimuth': obj['angles']['azimuth']
                    })
                else:
                    # Static landmarks
                    landmarks.append({
                        'id': obj['id'],
                        'type': 'static',
                        'class': obj['class_name'],
                        'position': obj['position'],
                        'range': obj['range'],
                        'azimuth': obj['angles']['azimuth']
                    })
        
        # Send to your navigation system
        if obstacles:
            rospy.loginfo(f"Found {len(obstacles)} obstacles for navigation")
            # self.send_to_navigation_system(obstacles, landmarks)
        
        return obstacles, landmarks
    
    def send_to_navigation_system(self, obstacles, landmarks):
        """
        Send processed data to your navigation/SLAM system
        Implement your specific communication method here
        """
        # Example: You can publish to other ROS topics, 
        # call service, or write to shared memory
        pass
    
    def save_detection_data(self, frame_data):
        """Save detection data to JSON file"""
        try:
            with open(self.output_file, 'a') as f:
                json.dump(frame_data, f)
                f.write('\n')
        except Exception as e:
            rospy.logerr(f"Error saving detection data: {e}")
    
    def log_statistics(self, event):
        """Periodic logging of statistics"""
        if self.total_frames > 0:
            elapsed_time = time.time() - self.start_time
            avg_fps = self.total_frames / elapsed_time if elapsed_time > 0 else 0
            avg_objects_per_frame = self.total_objects / self.total_frames
            
            rospy.loginfo(
                f"Detection Statistics: "
                f"Frames: {self.total_frames}, "
                f"Objects: {self.total_objects}, "
                f"Avg FPS: {avg_fps:.1f}, "
                f"Avg Objects/Frame: {avg_objects_per_frame:.1f}"
            )
            
            # Log tracked objects
            active_tracks = len([track for track in self.object_tracks.values() if len(track) > 0])
            rospy.loginfo(f"Active object tracks: {active_tracks}")
    
    def get_latest_detections(self):
        """Get the most recent detection data"""
        return self.latest_detections
    
    def get_object_track(self, object_id):
        """Get tracking history for a specific object"""
        return self.object_tracks.get(object_id, [])
    
    def get_active_objects(self, max_age_seconds=1.0):
        """Get objects that were detected recently"""
        current_time = time.time()
        active_objects = []
        
        for obj_id, track_history in self.object_tracks.items():
            if track_history:
                last_detection = track_history[-1]
                age = current_time - last_detection['timestamp']
                
                if age <= max_age_seconds:
                    active_objects.append({
                        'id': obj_id,
                        'last_seen': age,
                        'position': last_detection['position'],
                        'range': last_detection['range'],
                        'angles': last_detection['angles']
                    })
        
        return active_objects


def main():
    try:
        # Create subscriber node
        subscriber = ObjectDetectionSubscriber()
        
        rospy.loginfo("Object Detection Subscriber is running...")
        rospy.loginfo("Press Ctrl+C to stop")
        
        # Keep node running
        rospy.spin()
        
    except rospy.ROSInterruptException:
        rospy.loginfo("Subscriber node interrupted")
    except Exception as e:
        rospy.logerr(f"Subscriber node failed: {e}")


if __name__ == '__main__':
    main()
