#!/usr/bin/env python3
"""
Test script for ROS Real-time Object Detection
Tests the detection system without requiring a physical camera
"""

import rospy
import numpy as np
import cv2
import time
from std_msgs.msg import Header
from geometry_msgs.msg import Point

try:
    from realtime_object_detection.msg import DetectedObject, DetectedObjects
except ImportError:
    print("❌ Custom messages not found. Build the package first:")
    print("cd ~/catkin_ws && catkin_make && source devel/setup.bash")
    exit(1)


class DetectionTester:
    """Test the detection system with simulated data"""
    
    def __init__(self):
        rospy.init_node('detection_tester', anonymous=True)
        
        # Publisher for test data
        self.pub = rospy.Publisher('/detected_objects', DetectedObjects, queue_size=10)
        
        # Test parameters
        self.frame_id = 0
        self.test_objects = [
            {'id': 1, 'class': 'person', 'x': 0.5, 'y': 0.2, 'z': 2.0},
            {'id': 2, 'class': 'car', 'x': -1.0, 'y': 0.0, 'z': 5.0},
            {'id': 3, 'class': 'bicycle', 'x': 2.0, 'y': -0.3, 'z': 3.5}
        ]
        
        rospy.loginfo("Detection Tester initialized")
    
    def create_test_message(self):
        """Create a test DetectedObjects message"""
        msg = DetectedObjects()
        
        # Header
        msg.header = Header()
        msg.header.stamp = rospy.Time.now()
        msg.header.frame_id = 'camera_link'
        
        # Frame info  
        msg.frame_id = self.frame_id
        msg.detection_count = len(self.test_objects)
        msg.processing_time = 0.05  # 50ms
        msg.camera_frame = 'camera_link'
        msg.camera_position = Point(0, 0, 0)
        msg.fps = 20.0
        msg.gpu_available = True
        
        # Create test objects
        msg.objects = []
        for obj_data in self.test_objects:
            obj = DetectedObject()
            
            # Header
            obj.header = msg.header
            
            # Object info
            obj.id = obj_data['id']
            obj.class_name = obj_data['class']
            obj.confidence = 0.85
            
            # Position
            obj.position = Point()
            obj.position.x = obj_data['x'] + np.random.normal(0, 0.1)  # Add noise
            obj.position.y = obj_data['y'] + np.random.normal(0, 0.05)
            obj.position.z = obj_data['z'] + np.random.normal(0, 0.2)
            
            # Calculate angles
            obj.azimuth = np.arctan2(obj.position.x, obj.position.z) * 180.0 / np.pi
            obj.elevation = np.arctan2(-obj.position.y, obj.position.z) * 180.0 / np.pi
            
            # Range
            obj.range = obj.position.z
            obj.depth_mm = obj.position.z * 1000.0
            
            # Bounding box (simulated)
            obj.bbox = [100 + obj_data['id']*50, 100, 200 + obj_data['id']*50, 200]
            
            # Metadata
            obj.valid_depth = True
            obj.frame_id = self.frame_id
            
            msg.objects.append(obj)
        
        return msg
    
    def run_test(self, duration=30):
        """Run test for specified duration"""
        rospy.loginfo(f"🧪 Starting detection test for {duration} seconds")
        rospy.loginfo("📡 Publishing test data to /detected_objects")
        
        rate = rospy.Rate(20)  # 20 Hz
        start_time = time.time()
        
        while not rospy.is_shutdown() and (time.time() - start_time) < duration:
            # Create and publish test message
            test_msg = self.create_test_message()
            self.pub.publish(test_msg)
            
            # Log periodically
            if self.frame_id % 100 == 0:
                rospy.loginfo(f"📊 Published frame {self.frame_id} with {len(self.test_objects)} objects")
            
            self.frame_id += 1
            rate.sleep()
        
        rospy.loginfo("✅ Test completed successfully")


def test_subscriber():
    """Test the subscriber functionality"""
    rospy.init_node('subscriber_tester', anonymous=True)
    
    def callback(msg):
        rospy.loginfo(f"📨 Received frame {msg.frame_id} with {msg.detection_count} objects:")
        for obj in msg.objects:
            rospy.loginfo(
                f"  • {obj.class_name} (ID:{obj.id}): "
                f"pos=({obj.position.x:.2f}, {obj.position.y:.2f}, {obj.position.z:.2f}), "
                f"angles=({obj.azimuth:.1f}°, {obj.elevation:.1f}°), "
                f"range={obj.range:.2f}m"
            )
    
    sub = rospy.Subscriber('/detected_objects', DetectedObjects, callback)
    rospy.loginfo("🎧 Subscriber test started. Listening for messages...")
    rospy.spin()


def main():
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == 'subscriber':
        # Test subscriber
        test_subscriber()
    else:
        # Test publisher
        try:
            tester = DetectionTester()
            tester.run_test(30)  # Run for 30 seconds
        except rospy.ROSInterruptException:
            rospy.loginfo("Test interrupted")


if __name__ == '__main__':
    main()
