"""
Object Detection Processor for Real-time YOLO Detection with Depth Information
Integrates YOLO v11 object detection with Intel RealSense depth data
"""

import cv2
import numpy as np
import os
import time
from typing import Optional, Tuple, Dict, List
import json

try:
    from ultralytics import YOLO
    import supervision as sv
    import torch
    DETECTION_AVAILABLE = True
except ImportError as e:
    DETECTION_AVAILABLE = False
    IMPORT_ERROR = str(e)

class ObjectDetectionProcessor:
    """Handles real-time object detection with depth information"""
    
    def __init__(self, model_path: str = "PredictModel/best PT 3500.pt"):
        self.model_path = model_path
        self.model = None
        self.tracker = None
        self.box_annotator = None
        self.label_annotator = None
        
        # Performance tracking
        self.frame_count = 0
        self.processing_times = []
        self.detection_stats = {
            'objects_detected': 0,
            'avg_processing_time': 0.0,
            'model_loaded': False,
            'last_detection_count': 0
        }
        
        # Configuration from notebook
        self.YOLO_INPUT_SIZE = 640
        self.CENTER_REGION_RATIO = 0.6
        self.DEPTH_OUTLIER_THRESHOLD = 2.0
        self.LABEL_FONT_SCALE = 0.8
        self.LABEL_FONT_THICKNESS = 2
        self.LABEL_PADDING = 8
        
        # Recording metadata
        self.detection_metadata = []
        
    def check_dependencies(self) -> Tuple[bool, str]:
        """Check if required dependencies are available"""
        if not DETECTION_AVAILABLE:
            return False, f"Missing dependencies: {IMPORT_ERROR}"
        return True, "All dependencies available"
    
    def load_model(self, model_path: Optional[str] = None) -> Tuple[bool, str]:
        """Load YOLO model and initialize components"""
        if not DETECTION_AVAILABLE:
            return False, "Detection dependencies not available"
        
        if model_path:
            self.model_path = model_path
            
        if not os.path.exists(self.model_path):
            return False, f"Model file not found: {self.model_path}"
        
        try:
            # Load YOLO model with proper handling for PyTorch 2.6+ weights_only behavior
            import torch
            
            # Check ultralytics version and handle compatibility
            try:
                import ultralytics
                from ultralytics.nn.modules import block
                
                print(f"Ultralytics version: {ultralytics.__version__}")
                
                # Check if required modules exist for the model
                missing_modules = []
                if not hasattr(block, 'C3k2'):
                    missing_modules.append('C3k2')
                
                if missing_modules:
                    print(f"⚠ Missing modules in current ultralytics version: {missing_modules}")
                    print("This model requires a newer version of ultralytics")
                    print("Please run: pip install ultralytics>=8.2.0")
                    
                    # Try compatibility workarounds
                    for module_name in missing_modules:
                        if module_name == 'C3k2':
                            if hasattr(block, 'C2f'):
                                setattr(block, 'C3k2', getattr(block, 'C2f'))
                                print(f"✓ Added {module_name} compatibility using C2f")
                            elif hasattr(block, 'C3'):
                                setattr(block, 'C3k2', getattr(block, 'C3'))
                                print(f"✓ Added {module_name} compatibility using C3")
                            else:
                                print(f"❌ Cannot create compatibility for {module_name}")
                                
            except Exception as compat_error:
                print(f"⚠ Version compatibility check failed: {compat_error}")
            
            # Temporarily set torch.load to use weights_only=False for trusted model loading
            # This is necessary for custom trained YOLO models with PyTorch 2.6+
            original_load = torch.load
            def safe_load_for_yolo(*args, **kwargs):
                # Force weights_only=False for model loading (trusted source)
                kwargs['weights_only'] = False
                return original_load(*args, **kwargs)
            
            # Patch torch.load temporarily
            torch.load = safe_load_for_yolo
            
            try:
                self.model = YOLO(self.model_path)
                print("✓ YOLO model loaded successfully")
            finally:
                # Always restore original torch.load
                torch.load = original_load
            
            # Performance optimizations
            self.model.overrides['imgsz'] = self.YOLO_INPUT_SIZE
            
            # Check for GPU and use half precision if available
            if torch.cuda.is_available():
                try:
                    self.model.to('cuda')
                    self.model.half()
                    print("Using GPU with half precision")
                except:
                    print("GPU available but half precision failed, using full precision")
            
            # Warmup the model
            dummy_img = np.zeros((480, 640, 3), dtype=np.uint8)
            _ = self.model(dummy_img, verbose=False)
            
            # Initialize tracker and annotators
            self.tracker = sv.ByteTrack()
            self.box_annotator = sv.BoxAnnotator()
            self.label_annotator = sv.LabelAnnotator(
                text_scale=self.LABEL_FONT_SCALE,
                text_thickness=self.LABEL_FONT_THICKNESS,
                text_padding=self.LABEL_PADDING,
                text_color=sv.Color.WHITE
            )
            
            self.detection_stats['model_loaded'] = True
            return True, f"Model loaded successfully: {os.path.basename(self.model_path)}"
            
        except Exception as e:
            return False, f"Failed to load model: {str(e)}"
    
    def calculate_depth_robust_center(self, depth_array: np.ndarray, bbox: List[float]) -> float:
        """
        Calculate depth using robust center method with outlier removal
        Based on the notebook implementation
        """
        x1, y1, x2, y2 = int(bbox[0]), int(bbox[1]), int(bbox[2]), int(bbox[3])
        
        # Calculate center region
        width = x2 - x1
        height = y2 - y1
        
        margin_x = int(width * (1 - self.CENTER_REGION_RATIO) / 2)
        margin_y = int(height * (1 - self.CENTER_REGION_RATIO) / 2)
        
        center_x1 = max(0, x1 + margin_x)
        center_y1 = max(0, y1 + margin_y)
        center_x2 = min(depth_array.shape[1], x2 - margin_x)
        center_y2 = min(depth_array.shape[0], y2 - margin_y)
        
        if center_x2 <= center_x1 or center_y2 <= center_y1:
            return 0.0
        
        bbox_depth = depth_array[center_y1:center_y2, center_x1:center_x2]
        valid_depth = bbox_depth[(bbox_depth > 0) & (bbox_depth < 10000)]
        
        if len(valid_depth) < 5:
            return 0.0
        
        # Remove statistical outliers
        mean_depth = np.mean(valid_depth)
        std_depth = np.std(valid_depth)
        
        # Keep only values within threshold standard deviations
        filtered_depth = valid_depth[
            np.abs(valid_depth - mean_depth) <= self.DEPTH_OUTLIER_THRESHOLD * std_depth
        ]
        
        return float(np.mean(filtered_depth)) if len(filtered_depth) > 0 else float(mean_depth)
<<<<<<< HEAD
    
    def process_frame(self, rgb_frame: np.ndarray, depth_frame: np.ndarray) -> Tuple[np.ndarray, Dict]:
=======

    def calculate_3d_position_and_angles(self, bbox: List[float], depth_value: float, 
                                       camera_intrinsics: dict) -> Dict:
>>>>>>> b5a60f6 (3d coords)
        """
        Calculate 3D position (x, y, z) and angles (azimuth, elevation) for detected object
        
        Args:
            bbox: Bounding box coordinates [x1, y1, x2, y2]
            depth_value: Depth in millimeters from center of bbox
            camera_intrinsics: Camera intrinsic parameters (fx, fy, cx, cy)
        
        Returns:
            Dictionary containing 3D coordinates and angles
        """
        if depth_value <= 0:
            return {
                'x': 0.0, 'y': 0.0, 'z': 0.0,
                'azimuth': 0.0, 'elevation': 0.0,
                'valid': False
            }
        
        # Get bounding box center in pixel coordinates
        x1, y1, x2, y2 = bbox
        pixel_x = (x1 + x2) / 2.0
        pixel_y = (y1 + y2) / 2.0
        
        # Camera intrinsic parameters (defaults for D435i)
        fx = camera_intrinsics.get('fx', 616.4)  # focal length in x
        fy = camera_intrinsics.get('fy', 616.8)  # focal length in y  
        cx = camera_intrinsics.get('cx', 320.0)  # principal point x
        cy = camera_intrinsics.get('cy', 240.0)  # principal point y
        
        # Convert depth from mm to meters
        z = depth_value / 1000.0
        
        # Calculate 3D coordinates using pinhole camera model
        x = (pixel_x - cx) * z / fx
        y = (pixel_y - cy) * z / fy
        
        # Calculate azimuth angle (horizontal angle from center)
        # Positive azimuth = right side, negative = left side
        azimuth = np.arctan2(x, z) * 180.0 / np.pi
        
        # Calculate elevation angle (vertical angle from center)
        # Positive elevation = above center, negative = below center
        elevation = np.arctan2(-y, z) * 180.0 / np.pi
        
        return {
            'x': float(x),           # meters, right is positive
            'y': float(y),           # meters, down is positive (camera frame)
            'z': float(z),           # meters, forward is positive
            'azimuth': float(azimuth),    # degrees, right is positive
            'elevation': float(elevation), # degrees, up is positive
            'valid': True
        }

    def process_frame(self, rgb_frame: np.ndarray, depth_frame: np.ndarray, 
                     camera_intrinsics: Optional[dict] = None) -> Tuple[np.ndarray, Dict]:
        """
        Process frame with object detection, depth calculation, and 3D positioning
        Returns annotated frame and detection info including 3D coordinates and angles
        """
        if not self.model or not DETECTION_AVAILABLE:
            return rgb_frame, {'error': 'Model not loaded'}

        if camera_intrinsics is None:
            # Default D435i intrinsics (should be replaced with actual calibration)
            camera_intrinsics = {
                'fx': 616.4, 'fy': 616.8,
                'cx': 320.0, 'cy': 240.0
            }
        
        start_time = time.time()
        
        try:
            # Run YOLO detection
            results = self.model(rgb_frame, imgsz=self.YOLO_INPUT_SIZE, verbose=False)[0]
            detections = sv.Detections.from_ultralytics(results)
            
            # Update tracker
            if self.tracker:
                detections = self.tracker.update_with_detections(detections)
            
            # Calculate depths and 3D positions for each detection
            depth_values = []
            detection_info = []
            
            if len(detections.xyxy) > 0:
                for i, bbox in enumerate(detections.xyxy):
                    avg_depth = self.calculate_depth_robust_center(depth_frame, bbox)
                    depth_values.append(avg_depth)
                    
                    # Calculate 3D position and angles
                    position_data = self.calculate_3d_position_and_angles(
                        bbox, avg_depth, camera_intrinsics
                    )
                    
                    # Store detection info for metadata
                    if hasattr(detections, 'class_id') and hasattr(detections, 'tracker_id'):
                        class_id = detections.class_id[i] if detections.class_id is not None and i < len(detections.class_id) else None
                        tracker_id = detections.tracker_id[i] if detections.tracker_id is not None and i < len(detections.tracker_id) else None
                        confidence = detections.confidence[i] if hasattr(detections, 'confidence') and detections.confidence is not None and i < len(detections.confidence) else None
                        class_name = results.names[class_id] if class_id is not None and hasattr(results, 'names') else "unknown"
                        
                        detection_info.append({
                            'tracker_id': int(tracker_id) if tracker_id is not None else None,
                            'class_id': int(class_id) if class_id is not None else None,
                            'class_name': class_name,
                            'confidence': float(confidence) if confidence is not None else None,
                            'bbox': [float(x) for x in bbox],
                            'depth_mm': float(avg_depth),
                            'depth_m': float(avg_depth / 1000.0) if avg_depth > 0 else 0.0,
                            # 3D position and angles
                            'position_3d': {
                                'x': position_data['x'],
                                'y': position_data['y'], 
                                'z': position_data['z'],
                                'azimuth': position_data['azimuth'],
                                'elevation': position_data['elevation'],
                                'valid': position_data['valid']
                            }
                        })
            
            # Create enhanced labels for annotation with 3D info
            labels = []
            if (hasattr(detections, 'class_id') and hasattr(detections, 'tracker_id') and 
                detections.class_id is not None and detections.tracker_id is not None):
                for i, (class_id, tracker_id) in enumerate(zip(detections.class_id, detections.tracker_id)):
                    class_name = results.names[class_id] if class_id is not None and hasattr(results, 'names') else "unknown"
                    
                    if i < len(detection_info) and detection_info[i]['position_3d']['valid']:
                        pos = detection_info[i]['position_3d']
                        # Multi-line label with 3D information
                        label = (f"#{tracker_id} {class_name}\n"
                                f"XYZ: ({pos['x']:.2f}, {pos['y']:.2f}, {pos['z']:.2f})m\n"
                                f"Az: {pos['azimuth']:.1f}° El: {pos['elevation']:.1f}°")
                    elif i < len(depth_values) and depth_values[i] > 0:
                        depth_m = depth_values[i] / 1000.0
                        label = f"#{tracker_id} {class_name}\nDepth: {depth_m:.2f}m"
                    else:
                        label = f"#{tracker_id} {class_name}\nNo depth data"
                    
                    labels.append(label)
            
            # Annotate frame
            annotated_frame = rgb_frame.copy()
            if self.box_annotator:
                annotated_frame = self.box_annotator.annotate(annotated_frame, detections=detections)
            if self.label_annotator:
                annotated_frame = self.label_annotator.annotate(annotated_frame, detections=detections, labels=labels)
            
            # Update statistics
            processing_time = (time.time() - start_time) * 1000  # Convert to ms
            self.processing_times.append(processing_time)
            if len(self.processing_times) > 30:  # Keep last 30 measurements
                self.processing_times.pop(0)
            
            self.detection_stats.update({
                'objects_detected': len(detections.xyxy),
                'avg_processing_time': np.mean(self.processing_times),
                'last_detection_count': len(detections.xyxy)
            })
            
            # Store metadata for recording
            frame_metadata = {
                'frame_number': self.frame_count,
                'timestamp': time.time(),
                'processing_time_ms': processing_time,
                'detections': detection_info
            }
            
            self.frame_count += 1
            
            return annotated_frame, frame_metadata
            
        except Exception as e:
            return rgb_frame, {'error': f'Processing failed: {str(e)}'}
    
    def get_statistics(self) -> Dict:
        """Get current detection statistics"""
        return self.detection_stats.copy()
    
    def add_detection_metadata(self, metadata: Dict):
        """Add frame metadata for recording"""
        self.detection_metadata.append(metadata)
    
    def save_detection_metadata(self, output_path: str) -> bool:
        """Save detection metadata to JSON file"""
        try:
            metadata_file = output_path.replace('.avi', '_detections.json').replace('.mp4', '_detections.json')
            with open(metadata_file, 'w') as f:
                json.dump({
                    'total_frames': len(self.detection_metadata),
                    'model_path': self.model_path,
                    'config': {
                        'center_region_ratio': self.CENTER_REGION_RATIO,
                        'depth_outlier_threshold': self.DEPTH_OUTLIER_THRESHOLD,
                        'yolo_input_size': self.YOLO_INPUT_SIZE
                    },
                    'frames': self.detection_metadata
                }, f, indent=2)
            print(f"Detection metadata saved: {metadata_file}")
            return True
        except Exception as e:
            print(f"Failed to save metadata: {e}")
            return False
    
    def clear_metadata(self):
        """Clear stored detection metadata"""
        self.detection_metadata.clear()
        self.frame_count = 0 